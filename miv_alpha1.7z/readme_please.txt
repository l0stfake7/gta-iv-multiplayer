Thank you for downloading this release of Multiplayer IV.
This software is licensed under MIT license which goes like that:

The MIT License (MIT)

Copyright (c) 2014 achlubek

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.

Thank you for reading license. 

How to setup server?
Run MIVServer.exe and server will start listening on port 9999

How to setup client?
Paste all from directory 'client' to your GTA IV installation directory (that which contains GTAIV.exe and paul.dll).
Then edit server.ini and provide correct data.
Then run GTA IV
After ensuring you are out of building - press L key and MIV will connect to server. 

Enjoy playing!