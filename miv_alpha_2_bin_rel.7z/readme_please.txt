Thank you for downloading this release of Multiplayer IV.
Thanks for Scripthook and Scripthook.net authors!

Look at http://achlubek.github.io/gta-iv-multiplayer/ for updates

How to setup server?
	Edit config.ini and provide own configuration
	Run MIVServer.exe and server will start listening on ports from config file
	Done!

How to setup client?
	Paste all from directory 'client' to your GTA IV installation directory (that which contains GTAIV.exe and paul.dll).
	Then edit server.ini and provide correct data.
	Then run GTA IV
	After ensuring you are out of building - press L key and MIV will connect to server. 

Enjoy playing!